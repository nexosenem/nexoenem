(() => {
'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const letters=['A','B','C','D','E'];
const cfg=window.NEXO_CONFIG||{};
let questions=[], visualManifest=new Set(), current=null, selected=null, answered=false, adminUnlocked=false;
const state=loadState();

function loadState(){
  const base={theme:'dark',attempts:[],seen:[],essays:[],feedback:[],videos:[],adminPinHash:'',cycle:1};
  try{return {...base,...JSON.parse(localStorage.getItem('nexo_state')||'{}')}}catch{return base}
}
function save(){localStorage.setItem('nexo_state',JSON.stringify(state))}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2300)}
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
function esc(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function pct(a,b){return b?Math.round(a/b*100):0}
function api(path){return (cfg.API_BASE||'').replace(/\/$/,'')+path}

async function init(){
  document.documentElement.dataset.theme=state.theme||'dark';
  const [q,m]=await Promise.all([fetch('data/questions.json').then(r=>r.json()),fetch('data/visual-manifest.json').then(r=>r.json())]);
  visualManifest=new Set(m);
  questions=q.filter(x=>!x.visualAsset||visualManifest.has(x.visualAsset));
  $('#base-count').textContent=`${questions.length} questões verificadas`;
  wireGlobal(); renderDashboard();renderQuestions();renderFocus();renderEssay();renderVideos();renderFeedback();renderAdmin();
}
function wireGlobal(){
  $$('#nav .nav-item').forEach(b=>b.onclick=()=>showView(b.dataset.view));
  $('#theme-btn').onclick=()=>{state.theme=state.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=state.theme;save()};
  $('#menu-btn').onclick=()=>$('#sidebar').classList.toggle('open');
}
function showView(v){
  $$('.view').forEach(x=>x.classList.toggle('active',x.id===`view-${v}`));
  $$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.view===v));
  $('#sidebar').classList.remove('open');
  const names={dashboard:['Painel adaptativo','Visão geral'],questions:['Banco inteligente','Questões'],focus:['Reforço personalizado','Meu foco'],essay:['Simulador de correção','Redação'],videos:['Biblioteca de conteúdo','Videoaulas'],feedback:['Sua voz importa','Feedback'],admin:['Área restrita','Admin']};
  $('#eyebrow').textContent=names[v][0];$('#view-title').textContent=names[v][1];window.scrollTo({top:0,behavior:'smooth'});
  if(v==='dashboard')renderDashboard(); if(v==='focus')renderFocus(); if(v==='videos')renderVideos(); if(v==='admin')renderAdmin();
}
function attemptStats(){
  const a=state.attempts, correct=a.filter(x=>x.correct).length;
  const by={};
  for(const x of a){const k=x.area||'Outros';by[k]??={n:0,c:0};by[k].n++;if(x.correct)by[k].c++}
  return {n:a.length,correct,accuracy:pct(correct,a.length),by};
}
function weakTopics(){
  const map={};
  state.attempts.forEach(a=>{const k=`${a.subject}|${a.topic}`;map[k]??={subject:a.subject,topic:a.topic,n:0,c:0};map[k].n++;if(a.correct)map[k].c++});
  return Object.values(map).map(x=>({...x,acc:pct(x.c,x.n),weakness:100-pct(x.c,x.n)})).sort((a,b)=>b.weakness-a.weakness||b.n-a.n);
}
function renderDashboard(){
  const s=attemptStats(), weak=weakTopics()[0];
  $('#view-dashboard').innerHTML=`
  <div class="hero"><div class="hero-kicker">NEXO ADAPT • ciclo ${state.cycle}</div><h2>Seu estudo muda conforme você responde.</h2><p>O sistema registra acertos e erros por matéria e tema, evita repetir questões já vistas e prioriza os pontos em que sua taxa de acerto é menor.</p><div class="hero-actions"><button class="btn primary" id="dash-train">⚡ Iniciar treino adaptativo</button><button class="btn ghost" id="dash-essay">✦ Corrigir redação</button></div></div>
  <div class="grid stats">
    ${metric('Questões resolvidas',s.n,`${Math.max(0,questions.length-state.seen.length)} inéditas disponíveis`)}
    ${metric('Taxa de acerto',`${s.accuracy}%`,s.n?'baseada no seu histórico':'responda sua primeira questão')}
    ${metric('Redações analisadas',state.essays.length,'estimativa pelas 5 competências')}
    ${metric('Foco atual',weak?weak.subject:'Diagnóstico',weak?`${weak.topic} • ${weak.acc}% de acerto`:'ainda sem histórico')}
  </div>
  <div class="grid two-col">
    <div class="card"><div class="section-head"><div><h3>Desempenho por área</h3><p>Atualizado a cada resposta</p></div></div><div class="subject-bars">${['Linguagens','Ciências Humanas','Ciências da Natureza','Matemática'].map(a=>{const d=s.by[a]||{n:0,c:0};const p=pct(d.c,d.n);return `<div class="bar-row"><span>${a}</span><div class="bar"><i style="width:${p}%"></i></div><b>${p}%</b></div>`}).join('')}</div></div>
    <div class="card"><div class="section-head"><div><h3>Precisão geral</h3><p>${s.correct} acertos em ${s.n} respostas</p></div></div><div class="donut-wrap"><div class="donut" style="--pct:${s.accuracy}"><b>${s.accuracy}%</b></div><div class="legend"><span><i></i> Acertos: ${s.correct}</span><span><i style="background:var(--surface2)"></i> Erros: ${s.n-s.correct}</span><span><i style="background:var(--brand2)"></i> Vistas: ${state.seen.length}/${questions.length}</span></div></div></div>
  </div>`;
  $('#dash-train').onclick=()=>{showView('questions');setTimeout(()=>pickQuestion(true),50)};
  $('#dash-essay').onclick=()=>showView('essay');
}
function metric(label,val,sub){return `<div class="card"><div class="metric-label">${esc(label)}</div><div class="metric-value">${esc(val)}</div><div class="metric-sub">${esc(sub)}</div><span class="metric-chip">tempo real</span></div>`}

function renderQuestions(){
  const subjects=[...new Set(questions.map(q=>q.subject))].sort();
  $('#view-questions').innerHTML=`<div class="section-head"><div><h2>Banco de questões</h2><p>${questions.length} questões extraídas dos cadernos enviados • sem repetição automática</p></div><button class="btn small danger" id="reset-cycle">↻ Novo ciclo</button></div>
  <div class="filterbar"><select id="q-area"><option value="">Todas as áreas</option>${[...new Set(questions.map(q=>q.area))].map(x=>`<option>${esc(x)}</option>`).join('')}</select><select id="q-sub"><option value="">Todas as matérias</option>${subjects.map(x=>`<option>${esc(x)}</option>`).join('')}</select><select id="q-diff"><option value="">Todas as dificuldades</option><option>Fácil</option><option>Média</option><option>Difícil</option></select><button class="btn primary" id="new-q">Nova questão</button><button class="btn" id="adaptive-q">⚡ Adaptativa</button></div>
  <div class="question-layout"><div id="question-slot"></div><aside class="side-stack"><div class="card progress-card"><div class="metric-label">Ciclo atual</div><div class="big" id="seen-count">${state.seen.length}</div><small>questões vistas de ${questions.length}</small><div class="progress"><i style="width:${pct(state.seen.length,questions.length)}%"></i></div></div><div class="card"><div class="metric-label">Como funciona</div><div class="mini-list"><div><span>Inéditas primeiro</span><b>✓</b></div><div><span>Recurso visual validado</span><b>✓</b></div><div><span>Adaptação por erro</span><b>✓</b></div></div></div></aside></div>`;
  $('#new-q').onclick=()=>pickQuestion(false); $('#adaptive-q').onclick=()=>pickQuestion(true);
  $('#reset-cycle').onclick=()=>{if(confirm('Iniciar um novo ciclo permite rever as 500 questões. O histórico de desempenho será mantido.')){state.seen=[];state.cycle++;save();toast('Novo ciclo iniciado');renderQuestions();pickQuestion(false)}};
  pickQuestion(false);
}
function filtered(){const a=$('#q-area')?.value||'',s=$('#q-sub')?.value||'',d=$('#q-diff')?.value||'';return questions.filter(q=>(!a||q.area===a)&&(!s||q.subject===s)&&(!d||q.difficulty===d)&&!state.seen.includes(q.id))}
function pickQuestion(adaptive=false){
  let pool=filtered();
  const slot=$('#question-slot');if(!slot)return;
  if(!pool.length){slot.innerHTML=`<div class="card empty"><h3>Você concluiu este filtro.</h3><p>Troque os filtros ou inicie um novo ciclo para rever questões.</p></div>`;return}
  if(adaptive && state.attempts.length){
    const weak=weakTopics(); const top=weak.slice(0,5).map(x=>x.topic);
    const focus=pool.filter(q=>top.includes(q.topic)); if(focus.length)pool=focus;
  }
  current=pool[Math.floor(Math.random()*pool.length)]; selected=null;answered=false;renderQuestion();
}
function renderQuestion(){
 const q=current;if(!q)return;const slot=$('#question-slot');
 const visual=q.visualAsset&&visualManifest.has(q.visualAsset)?`<div class="visual-wrap"><img src="${q.visualAsset}" alt="Recurso visual da questão ${q.number}" loading="lazy"><div class="visual-note">Recurso visual do caderno oficial • exibido antes do comando</div></div>`:'';
 slot.innerHTML=`<article class="card question-card"><div class="question-top"><div class="chips"><span class="chip brand">${esc(q.area)}</span><span class="chip">${esc(q.subject)}</span><span class="chip">${esc(q.difficulty)}</span></div><span class="chip">${q.year} • Q${q.number}</span></div><div class="question-body">${q.textBase?`<div class="text-label">Texto-base</div><div class="base-text">${esc(q.textBase)}</div>`:''}${visual}<div class="text-label">Comando</div><div class="prompt">${esc(q.prompt)}</div><div class="options">${q.options.map((o,i)=>`<button class="option" data-i="${i}"><b>${letters[i]}</b><span>${esc(o)}</span></button>`).join('')}</div><div id="q-explain"></div></div><div class="question-footer"><div class="source">Fonte: ${esc(q.source)}</div><button class="btn primary" id="submit-q" disabled>Confirmar resposta</button></div></article>`;
 $$('.option',slot).forEach(b=>b.onclick=()=>{if(answered)return;selected=+b.dataset.i;$$('.option',slot).forEach(x=>x.classList.toggle('selected',+x.dataset.i===selected));$('#submit-q').disabled=false});
 $('#submit-q').onclick=submitQuestion;
}
function submitQuestion(){if(answered||selected==null)return;answered=true;const q=current,correct=selected===q.answerIndex;$$('.option',$('#question-slot')).forEach((b,i)=>{if(i===q.answerIndex)b.classList.add('correct');else if(i===selected)b.classList.add('wrong')});
 state.attempts.push({id:q.id,area:q.area,subject:q.subject,topic:q.topic,difficulty:q.difficulty,correct,selected,answer:q.answerIndex,at:Date.now()});if(!state.seen.includes(q.id))state.seen.push(q.id);save();
 $('#q-explain').innerHTML=`<div class="explanation"><b>${correct?'Resposta correta.':'Resposta incorreta.'}</b><br>${esc(q.explanation)}</div>`;const btn=$('#submit-q');btn.textContent='Próxima questão';btn.disabled=false;btn.onclick=()=>pickQuestion(false);$('#seen-count').textContent=state.seen.length;toast(correct?'Acertou! Progresso atualizado.':'Erro registrado para o foco adaptativo.');}

function renderFocus(){
 const weak=weakTopics();
 $('#view-focus').innerHTML=`<div class="hero"><div class="hero-kicker">DIAGNÓSTICO DE LACUNAS</div><h2>O que mais precisa de atenção aparece primeiro.</h2><p>A prioridade é calculada pela sua taxa de erro em cada tema. Quanto mais você responde, mais específico fica o diagnóstico.</p></div><div class="grid focus-grid" style="margin-top:18px">${weak.length?weak.slice(0,9).map((x,i)=>`<div class="card focus-card"><span class="chip">Prioridade ${i+1}</span><div class="focus-score">${x.acc}%</div><h3>${esc(x.subject)}</h3><p>${esc(x.topic)} • ${x.n} tentativa${x.n>1?'s':''}</p><button class="btn small" data-topic="${esc(x.topic)}">Treinar tema</button></div>`).join(''):`<div class="card empty" style="grid-column:1/-1"><h3>Seu mapa de dificuldades ainda está vazio.</h3><p>Resolva algumas questões para a plataforma identificar os temas que merecem reforço.</p><button class="btn primary" id="focus-start">Começar diagnóstico</button></div>`}</div>`;
 $$('[data-topic]').forEach(b=>b.onclick=()=>{showView('questions');setTimeout(()=>{const topic=b.dataset.topic;let pool=questions.filter(q=>q.topic===topic&&!state.seen.includes(q.id));if(pool.length){current=pool[Math.floor(Math.random()*pool.length)];renderQuestion()}},30)});$('#focus-start')?.addEventListener('click',()=>showView('questions'));
}

function renderEssay(){
 const last=state.essays.at(-1);
 $('#view-essay').innerHTML=`<div class="grid essay-layout"><div class="card essay-editor"><div class="section-head"><div><h2>Laboratório de redação</h2><p>Simulação pedagógica com as 5 competências do ENEM</p></div></div><div class="field"><label>Tema da redação</label><input id="essay-theme" class="input" placeholder="Ex.: Desafios para combater..." value="${esc(last?.theme||'')}"></div><div class="field" style="margin-top:12px"><label>Sua redação</label><textarea id="essay-text" placeholder="Cole ou escreva sua redação aqui...">${esc(last?.text||'')}</textarea><div class="editor-meta"><span id="essay-count">0 palavras</span><span>Recomendação: texto dissertativo-argumentativo</span></div></div><button class="btn primary" id="essay-run" style="margin-top:14px">✦ Analisar redação</button><p style="font-size:10px;color:var(--muted);line-height:1.5">A nota é uma <b>estimativa automatizada</b>, não uma nota oficial do INEP. Use o resultado como diagnóstico de estudo e revisão.</p></div><div id="essay-result">${last?essayResult(last):essayEmpty()}</div></div>`;
 const t=$('#essay-text');const count=()=>$('#essay-count').textContent=`${(t.value.trim().match(/\S+/g)||[]).length} palavras`;t.oninput=count;count();$('#essay-run').onclick=runEssay;
}
function essayEmpty(){return `<div class="card empty"><div style="font-size:42px">✦</div><h3>Sua análise aparecerá aqui</h3><p>Você verá nota total, pontuação por competência, pontos fortes e erros explicados.</p></div>`}
async function runEssay(){const text=$('#essay-text').value.trim(),theme=$('#essay-theme').value.trim();if(text.length<300){toast('Escreva pelo menos cerca de 300 caracteres para analisar.');return}showLoader();await new Promise(r=>setTimeout(r,2100));const result=scoreEssay(text,theme);state.essays.push({theme,text,...result,at:Date.now()});save();hideLoader();renderEssay();toast('Análise concluída.');}
function showLoader(){const o=$('#essay-loader');o.classList.add('show');o.setAttribute('aria-hidden','false');let p=0;const phases=['Competência 1 • norma-padrão','Competência 2 • compreensão do tema','Competência 3 • argumentação','Competência 4 • coesão','Competência 5 • proposta de intervenção'];const timer=setInterval(()=>{p=Math.min(96,p+Math.ceil(Math.random()*9));$('#loader-pct').textContent=p+'%';$('#loader-bar').style.width=p+'%';$('.scan-ring').style.setProperty('--progress',p+'%');$('#loader-phase').textContent=phases[Math.min(4,Math.floor(p/20))];if(p>=96)clearInterval(timer)},130);o.dataset.timer=timer}
function hideLoader(){const o=$('#essay-loader');clearInterval(+o.dataset.timer);$('#loader-pct').textContent='100%';$('#loader-bar').style.width='100%';setTimeout(()=>o.classList.remove('show'),180)}
function band(v){return Math.max(0,Math.min(200,Math.round(v/40)*40))}
function scoreEssay(text,theme){
 const words=(text.toLowerCase().match(/[a-záàâãéêíóôõúç]+/gi)||[]),n=words.length,paras=text.split(/\n\s*\n/).filter(x=>x.trim()).length,sents=text.split(/[.!?]+/).filter(x=>x.trim()).length;
 const unique=new Set(words).size,lex=n?unique/n:0;const conn=['portanto','além disso','entretanto','contudo','assim','desse modo','nesse sentido','porém','todavia','logo','dessa forma','consequentemente'];const connCount=conn.reduce((a,c)=>a+(text.toLowerCase().match(new RegExp(`\\b${c}\\b`,'g'))||[]).length,0);
 const commonErrors=[['mais melhor','evite dupla comparação: use “melhor”'],['a nível de','prefira uma formulação direta, como “em relação a”'],['onde', 'verifique se “onde” está retomando realmente um lugar'],['através de','quando não houver ideia de atravessar, prefira “por meio de”']];
 const errors=[];commonErrors.forEach(([p,msg])=>{if(text.toLowerCase().includes(p))errors.push(`Expressão “${p}”: ${msg}.`)});
 const longSent=(text.match(/[^.!?]{190,}[.!?]/g)||[]).length;if(longSent)errors.push(`${longSent} período(s) muito longo(s): divida ideias para ganhar clareza e controle sintático.`);
 if(paras<3)errors.push('Estrutura com poucos parágrafos: separe introdução, desenvolvimento e conclusão de forma mais nítida.');
 if(n<180)errors.push('Texto curto para o padrão de uma redação completa: desenvolva melhor repertório, causas, consequências e proposta.');
 const themeWords=(theme.toLowerCase().match(/[a-záàâãéêíóôõúç]{5,}/g)||[]).filter(w=>!['sobre','desafios','brasil','brasileira','brasileiro'].includes(w));const adherence=themeWords.length?themeWords.filter(w=>text.toLowerCase().includes(w)).length/themeWords.length:.65;
 const agents=['governo','estado','escola','sociedade','mídia','empresas','ministério','prefeitura','família'];const actions=['deve','devem','promover','criar','implementar','investir','garantir','fiscalizar','oferecer','ampliar','desenvolver'];const means=['por meio','mediante','através','com campanhas','com investimentos','por intermédio'];const hasAgent=agents.some(x=>text.toLowerCase().includes(x)),hasAction=actions.some(x=>text.toLowerCase().includes(x)),hasMeans=means.some(x=>text.toLowerCase().includes(x));
 const c1=band(80+Math.min(80,lex*130)+Math.min(40,sents>5?25:0)-errors.length*12);
 const c2=band(70+adherence*110+(n>=180?20:0));
 const c3=band(60+Math.min(60,paras*16)+Math.min(60,lex*100));
 const c4=band(60+Math.min(100,connCount*15)+(paras>=4?30:0));
 const c5=band((hasAgent?55:10)+(hasAction?55:10)+(hasMeans?45:0)+(text.toLowerCase().includes('direito')||text.toLowerCase().includes('respeito')?35:15));
 const scores=[c1,c2,c3,c4,c5],strengths=[];
 if(c1>=160)strengths.push('Bom controle geral da norma-padrão e vocabulário variado.');if(c2>=160)strengths.push('O texto se mantém conectado ao tema informado.');if(c3>=160)strengths.push('Há organização argumentativa e progressão das ideias.');if(c4>=160)strengths.push('Uso consistente de conectivos e mecanismos de coesão.');if(c5>=160)strengths.push('A proposta de intervenção apresenta elementos concretos.');
 if(!hasAgent)errors.push('Competência 5: deixe claro quem executará a proposta de intervenção.');if(!hasAction)errors.push('Competência 5: explicite uma ação concreta, e não apenas uma intenção genérica.');if(!hasMeans)errors.push('Competência 5: detalhe o meio ou modo de execução da proposta.');if(connCount<3)errors.push('Competência 4: aumente a variedade de conectivos entre argumentos e parágrafos.');
 return {scores,total:scores.reduce((a,b)=>a+b,0),errors:errors.slice(0,8),strengths:strengths.length?strengths:['O texto tem material suficiente para revisão; use os pontos abaixo como roteiro de reescrita.'],stats:{words:n,paras,connectives:connCount}};
}
function essayResult(e){return `<div class="card"><div class="score-total"><div><div class="metric-label">Nota estimada</div><strong>${e.total}</strong><div class="metric-sub">de 1000 pontos</div></div><span class="chip brand">simulação</span></div><div class="competencies">${e.scores.map((x,i)=>`<div class="comp"><div class="comp-head"><span>C${i+1} • ${['Norma-padrão','Tema e repertório','Argumentação','Coesão','Intervenção'][i]}</span><b>${x}/200</b></div><div class="bar"><i style="width:${x/2}%"></i></div></div>`).join('')}</div><div class="feedback-block"><h4>Pontos fortes</h4>${e.strengths.map(x=>`<div class="feedback-item good">${esc(x)}</div>`).join('')}</div><div class="feedback-block"><h4>Erros e ajustes explicados</h4>${e.errors.map(x=>`<div class="feedback-item bad">${esc(x)}</div>`).join('')||'<div class="feedback-item good">Nenhum alerta estrutural forte foi detectado. Faça uma revisão manual de ortografia e repertório.</div>'}<div class="feedback-item">${e.stats.words} palavras • ${e.stats.paras} parágrafos • ${e.stats.connectives} conectivos detectados.</div></div></div>`}

async function renderVideos(){
 let vids=[...state.videos];
 if(cfg.API_BASE){try{const r=await fetch(api('/api/videos'));if(r.ok)vids=await r.json()}catch{}}
 $('#view-videos').innerHTML=`<div class="section-head"><div><h2>Videoaulas</h2><p>Conteúdo organizado por matéria e tema</p></div></div><div class="grid video-grid">${vids.length?vids.map(v=>`<article class="card video-card"><div class="video-thumb">▶</div><div class="video-body"><span class="chip brand">${esc(v.subject||'Geral')}</span><h3>${esc(v.title)}</h3><p>${esc(v.description||'')}</p>${v.url?`<a class="btn small" href="${esc(v.url)}" target="_blank" rel="noopener" style="margin-top:10px">Abrir aula</a>`:''}${v.blobKey?`<video controls src="${api('/media/'+v.blobKey)}"></video>`:''}</div></article>`).join(''):`<div class="card empty" style="grid-column:1/-1"><h3>A biblioteca ainda está vazia.</h3><p>O administrador pode adicionar links ou arquivos de videoaula pela área Admin.</p></div>`}</div>`;
}

function renderFeedback(){
 $('#view-feedback').innerHTML=`<div class="grid two-col"><div class="card"><div class="section-head"><div><h2>Envie sua opinião</h2><p>Use o feedback para sugerir melhorias ou relatar problemas</p></div></div><div class="field"><label>Categoria</label><select id="fb-cat"><option>Sugestão</option><option>Problema</option><option>Questão</option><option>Redação</option><option>Videoaula</option></select></div><div class="field" style="margin-top:12px"><label>Avaliação</label><div class="rating" id="stars">${[1,2,3,4,5].map(n=>`<button class="star" data-n="${n}">★</button>`).join('')}</div></div><div class="field"><label>Mensagem</label><textarea id="fb-msg" rows="7" placeholder="Conte o que funcionou e o que pode melhorar..."></textarea></div><button class="btn primary" id="fb-send" style="margin-top:12px">Enviar feedback</button></div><div class="card"><h3>Feedback útil é específico</h3><p style="color:var(--muted);font-size:12px;line-height:1.7">Se for um erro em questão, informe o ano e o número. Se for sobre usabilidade, diga em qual tela aconteceu e em qual dispositivo.</p><div class="mini-list"><div><span>Feedbacks enviados neste navegador</span><b>${state.feedback.length}</b></div><div><span>Privacidade</span><b>local por padrão</b></div></div></div></div>`;
 let rating=0;$$('.star').forEach(b=>b.onclick=()=>{rating=+b.dataset.n;$$('.star').forEach(s=>s.classList.toggle('on',+s.dataset.n<=rating))});
 $('#fb-send').onclick=async()=>{const message=$('#fb-msg').value.trim();if(!message){toast('Escreva uma mensagem.');return}const item={category:$('#fb-cat').value,rating,message,at:Date.now()};let remote=false;if(cfg.API_BASE){try{const r=await fetch(api('/api/feedback'),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(item)});remote=r.ok}catch{}}if(!remote){state.feedback.push(item);save()}toast('Feedback enviado. Obrigado!');renderFeedback()};
}

function renderAdmin(){
 const root=$('#view-admin');
 if(!state.adminPinHash){root.innerHTML=`<div class="card admin-lock"><div class="lock">⌘</div><h2>Configuração inicial do administrador</h2><p style="color:var(--muted);max-width:520px;margin:0 auto 18px">Crie um PIN para proteger os controles administrativos neste navegador. Para uma instalação multiusuário, use também o Worker backend incluído no pacote.</p><div class="field" style="max-width:320px;margin:auto"><input id="pin-new" class="input" type="password" inputmode="numeric" placeholder="Novo PIN (mínimo 4 caracteres)"><button class="btn primary" id="pin-create">Criar acesso</button></div></div>`;$('#pin-create').onclick=()=>{const p=$('#pin-new').value;if(p.length<4){toast('Use pelo menos 4 caracteres.');return}state.adminPinHash=hash(p);save();adminUnlocked=true;renderAdmin()};return}
 if(!adminUnlocked){root.innerHTML=`<div class="card admin-lock"><div class="lock">⌘</div><h2>Área do administrador</h2><p style="color:var(--muted)">Digite o PIN para gerenciar videoaulas e feedbacks.</p><div class="field" style="max-width:320px;margin:auto"><input id="pin-login" class="input" type="password" placeholder="PIN"><button class="btn primary" id="pin-enter">Entrar</button></div></div>`;$('#pin-enter').onclick=()=>{if(hash($('#pin-login').value)===state.adminPinHash){adminUnlocked=true;renderAdmin()}else toast('PIN incorreto.')};return}
 root.innerHTML=`<div class="grid admin-grid"><div class="card"><div class="section-head"><div><h2>Adicionar videoaula</h2><p>Link funciona imediatamente; arquivo usa R2 quando o backend estiver configurado.</p></div></div><div class="field"><label>Título</label><input id="v-title" class="input"></div><div class="field" style="margin-top:10px"><label>Matéria</label><input id="v-sub" class="input" placeholder="Ex.: Física"></div><div class="field" style="margin-top:10px"><label>Descrição</label><textarea id="v-desc" rows="3"></textarea></div><div class="field" style="margin-top:10px"><label>URL da videoaula</label><input id="v-url" class="input" type="url" placeholder="https://..."></div><div class="field" style="margin-top:10px"><label>Ou envie um arquivo de vídeo</label><input id="v-file" class="input" type="file" accept="video/*"></div><div class="field" style="margin-top:10px"><label>Chave do administrador (somente backend)</label><input id="v-key" class="input" type="password" placeholder="ADMIN_KEY"></div><button class="btn primary" id="v-save" style="margin-top:12px">Publicar videoaula</button></div><div class="card"><div class="section-head"><div><h2>Feedbacks</h2><p>Recebidos neste navegador</p></div></div><div class="feedback-list">${state.feedback.length?state.feedback.slice().reverse().map(f=>`<div class="feedback-entry"><strong>${esc(f.category)} • ${'★'.repeat(f.rating||0)}</strong><p>${esc(f.message)}</p><small>${new Date(f.at).toLocaleString('pt-BR')}</small></div>`).join(''):'<div class="empty">Nenhum feedback local ainda.</div>'}</div></div></div><div class="card" style="margin-top:18px"><div class="section-head"><div><h3>Modo de armazenamento</h3><p>${cfg.API_BASE?'Backend configurado: '+esc(cfg.API_BASE):'Local: dados salvos somente neste navegador'}</p></div><button class="btn small" id="admin-lock">Bloquear</button></div><p style="font-size:11px;color:var(--muted);line-height:1.6">Para alunos em vários dispositivos verem os mesmos vídeos e enviarem feedback ao administrador, publique o Worker em <code>backend/</code>, conecte D1 + R2 e informe a URL em <code>config.js</code>.</p></div>`;
 $('#admin-lock').onclick=()=>{adminUnlocked=false;renderAdmin()};$('#v-save').onclick=saveVideo;
}
async function saveVideo(){const title=$('#v-title').value.trim(),subject=$('#v-sub').value.trim(),description=$('#v-desc').value.trim(),url=$('#v-url').value.trim(),file=$('#v-file').files[0],key=$('#v-key').value;if(!title||(!url&&!file)){toast('Informe título e URL ou arquivo.');return}
 if(file&&cfg.API_BASE){const fd=new FormData();fd.append('file',file);fd.append('title',title);fd.append('subject',subject);fd.append('description',description);try{const r=await fetch(api('/api/admin/video-file'),{method:'POST',headers:{'x-admin-key':key},body:fd});if(!r.ok)throw 0;toast('Arquivo de vídeo publicado.');renderVideos();return}catch{toast('Falha no upload. Verifique ADMIN_KEY, R2 e D1.');return}}
 if(cfg.API_BASE){try{const r=await fetch(api('/api/admin/video-url'),{method:'POST',headers:{'content-type':'application/json','x-admin-key':key},body:JSON.stringify({title,subject,description,url})});if(r.ok){toast('Videoaula publicada.');renderAdmin();return}}catch{}}
 if(file){toast('Upload de arquivo compartilhado requer o backend Cloudflare/R2. Use uma URL ou configure o backend.');return}state.videos.push({id:crypto.randomUUID?.()||Date.now(),title,subject,description,url,at:Date.now()});save();toast('Videoaula salva localmente.');renderAdmin();}

init().catch(err=>{console.error(err);document.body.innerHTML='<main style="padding:40px;font-family:system-ui"><h1>Não foi possível carregar a base.</h1><p>Confirme se a pasta <code>data/</code> foi publicada junto com o site.</p></main>'});
})();
