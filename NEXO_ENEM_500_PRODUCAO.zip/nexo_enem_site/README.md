# NEXO ENEM — pacote de publicação

Plataforma estática responsiva com 500 questões únicas extraídas dos cadernos enviados, recursos visuais validados, modo adaptativo, painel de desempenho, foco por dificuldade, correção simulada de redação, tema claro/escuro, videoaulas, feedback e área administrativa.

## Publicar em HTTPS sem Termux

### Opção simples — Cloudflare Pages (site funciona imediatamente)
1. Entre no **Cloudflare Dashboard**.
2. Vá em **Workers & Pages** → **Create** → **Pages** / **Direct Upload**.
3. Envie o conteúdo desta pasta `nexo_enem_site` (ou conecte um repositório Git contendo esta pasta).
4. O Cloudflare cria um endereço `*.pages.dev` com HTTPS automaticamente.
5. Se tiver domínio próprio, abra **Custom domains** dentro do projeto e conecte-o.

Nesse modo, questões, redação, adaptação e desempenho funcionam sem backend. Progresso, feedback e links de videoaula ficam no navegador do usuário.

## Modo produção multiusuário — vídeos/feedback compartilhados
A pasta `backend/` contém um Worker opcional para Cloudflare D1 + R2.

1. Crie um banco **D1** chamado `nexo-enem` e rode `backend/schema.sql`.
2. Crie um bucket **R2** chamado `nexo-enem-media`.
3. Copie `backend/wrangler.toml.example` para `wrangler.toml` e preencha o ID do D1.
4. Configure o secret `ADMIN_KEY` no Worker.
5. Publique `backend/worker.js` e copie a URL HTTPS dele.
6. Coloque essa URL em `config.js`, na propriedade `API_BASE`.

Com isso, feedbacks passam a ser enviados ao D1 e arquivos de videoaula podem ser armazenados no R2.

## Segurança
O PIN da área Admin do site é uma trava local de interface. Em produção, uploads e rotas administrativas devem ser protegidos pelo `ADMIN_KEY` do Worker. Nunca coloque a chave secreta dentro de `config.js`.

## Dados das questões
- `data/questions.json`: 500 questões únicas.
- `data/visual-manifest.json`: lista exata dos recursos visuais existentes.
- `assets/pages/`: imagens das páginas necessárias para questões com mapas, gráficos, tabelas, diagramas, cartuns ou alternativas visuais.

O seletor só libera uma questão visual quando o arquivo correspondente consta no manifesto, evitando cards quebrados.

## Redação
O corretor é uma **simulação pedagógica**, não uma correção oficial do INEP. Ele estima C1–C5 em faixas de 40 pontos, gera nota de 0 a 1000 e explica alertas de estrutura, coesão e proposta de intervenção.
