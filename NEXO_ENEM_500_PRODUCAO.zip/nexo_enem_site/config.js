window.NEXO_CONFIG = {
  // Deixe vazio para usar armazenamento local. Se publicar o backend Cloudflare incluso,
  // coloque aqui a URL do Worker, ex.: "https://nexo-api.seudominio.workers.dev".
  API_BASE: ""
};
